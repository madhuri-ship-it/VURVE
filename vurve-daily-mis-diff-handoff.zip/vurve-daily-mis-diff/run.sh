#!/usr/bin/env bash
# Daily MIS diff runner. Called by launchd at 8:00 AM.
set -euo pipefail
cd "$(dirname "$0")"

mkdir -p logs
LOG="logs/run_$(date +%Y-%m-%d).log"
PY="$HOME/vurve-daily-mis-diff/.venv/bin/python3"

{
  echo "=== $(date '+%Y-%m-%d %H:%M:%S') start ==="
  "$PY" scripts/roll_month.py
  "$PY" scripts/daily_diff.py
  echo "=== $(date '+%Y-%m-%d %H:%M:%S') done ==="
} >> "$LOG" 2>&1
