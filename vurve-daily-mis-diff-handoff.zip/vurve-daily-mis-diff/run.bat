@echo off
REM Daily MIS diff runner for Windows. Called by Task Scheduler at 8:00 AM.
setlocal
cd /d "%~dp0"

if not exist "logs" mkdir logs

for /f "tokens=1-3 delims=/-" %%a in ("%DATE%") do set TODAY=%%c-%%b-%%a
set LOG=logs\run_%TODAY%.log

set PY=.venv\Scripts\python.exe

echo === %DATE% %TIME% start ===>> "%LOG%"
"%PY%" scripts\roll_month.py >> "%LOG%" 2>&1
"%PY%" scripts\daily_diff.py >> "%LOG%" 2>&1
echo === %DATE% %TIME% done ===>> "%LOG%"

endlocal
