"""Thin wrapper around Google Drive + Sheets for the daily MIS diff routine.

Reads MIS workbooks live via the Sheets API (never downloads them).
Writes diff rows and state to the master workbook via the Sheets API.
"""
from __future__ import annotations

import os
from typing import Any

import yaml
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build

SCOPES = [
    "https://www.googleapis.com/auth/drive",
    "https://www.googleapis.com/auth/spreadsheets",
]

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
CONFIG_PATH = os.path.join(ROOT, "config", "outlets.yaml")


def load_config() -> dict:
    with open(CONFIG_PATH) as f:
        return yaml.safe_load(f)


def _creds(cfg: dict) -> Credentials:
    secrets = os.path.join(ROOT, cfg["credentials"]["oauth_client_secrets"])
    token = os.path.join(ROOT, cfg["credentials"]["token_cache"])
    creds = None
    if os.path.exists(token):
        creds = Credentials.from_authorized_user_file(token, SCOPES)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(secrets, SCOPES)
            creds = flow.run_local_server(port=0)
        with open(token, "w") as f:
            f.write(creds.to_json())
    return creds


def col_letter(n: int) -> str:
    s = ""
    while n > 0:
        n, rem = divmod(n - 1, 26)
        s = chr(65 + rem) + s
    return s


class DriveClient:
    def __init__(self, cfg: dict | None = None):
        self.cfg = cfg or load_config()
        creds = _creds(self.cfg)
        self.drive = build("drive", "v3", credentials=creds, cache_discovery=False)
        self.sheets = build("sheets", "v4", credentials=creds, cache_discovery=False)

    # ---------- Drive: file lookup by exact name ----------
    def find_file(self, name: str, folder_id: str) -> dict | None:
        q = (
            f"name = '{name}' and "
            f"'{folder_id}' in parents and "
            f"trashed = false and "
            f"mimeType = 'application/vnd.google-apps.spreadsheet'"
        )
        resp = self.drive.files().list(
            q=q, fields="files(id,name)", pageSize=5
        ).execute()
        files = resp.get("files", [])
        return files[0] if files else None

    # ---------- Sheets: tabs ----------
    def list_tabs(self, spreadsheet_id: str) -> list[str]:
        meta = self.sheets.spreadsheets().get(
            spreadsheetId=spreadsheet_id,
            fields="sheets(properties(title))",
        ).execute()
        return [s["properties"]["title"] for s in meta.get("sheets", [])]

    def ensure_tab(self, spreadsheet_id: str, tab: str) -> None:
        if tab in self.list_tabs(spreadsheet_id):
            return
        self.sheets.spreadsheets().batchUpdate(
            spreadsheetId=spreadsheet_id,
            body={"requests": [{"addSheet": {"properties": {"title": tab}}}]},
        ).execute()

    # ---------- Sheets: read grid + notes ----------
    def read_grid_with_notes(
        self, spreadsheet_id: str, tab: str,
        max_rows: int = 500, max_cols: int = 100,
    ) -> dict:
        """Return {'values': [[...]], 'notes': [[...]]} bounded to a range."""
        rng = f"'{tab}'!A1:{col_letter(max_cols)}{max_rows}"
        resp = self.sheets.spreadsheets().get(
            spreadsheetId=spreadsheet_id,
            ranges=[rng],
            includeGridData=True,
            fields="sheets(data(rowData(values(formattedValue,note))))",
        ).execute()
        values: list[list] = []
        notes:  list[list] = []
        if not resp.get("sheets"):
            return {"values": values, "notes": notes}
        data = resp["sheets"][0].get("data", [])
        if not data:
            return {"values": values, "notes": notes}
        for row in data[0].get("rowData", []):
            vrow, nrow = [], []
            for cell in row.get("values", []) or []:
                vrow.append(cell.get("formattedValue"))
                nrow.append(cell.get("note"))
            values.append(vrow)
            notes.append(nrow)
        width = max((len(v) for v in values), default=0)
        values = [v + [None] * (width - len(v)) for v in values]
        notes  = [n + [None] * (width - len(n)) for n in notes]
        return {"values": values, "notes": notes}

    def read_values(self, spreadsheet_id: str, tab: str) -> list[list[Any]]:
        resp = self.sheets.spreadsheets().values().get(
            spreadsheetId=spreadsheet_id, range=f"'{tab}'"
        ).execute()
        return resp.get("values", [])

    # ---------- Sheets: writes ----------
    def append_rows(self, spreadsheet_id: str, tab: str,
                    rows: list[list[Any]]) -> None:
        if not rows:
            return
        self.ensure_tab(spreadsheet_id, tab)
        self.sheets.spreadsheets().values().append(
            spreadsheetId=spreadsheet_id,
            range=f"'{tab}'!A1",
            valueInputOption="RAW",
            insertDataOption="INSERT_ROWS",
            body={"values": rows},
        ).execute()

    def overwrite_tab(self, spreadsheet_id: str, tab: str,
                      rows: list[list[Any]]) -> None:
        self.ensure_tab(spreadsheet_id, tab)
        self.sheets.spreadsheets().values().clear(
            spreadsheetId=spreadsheet_id, range=f"'{tab}'"
        ).execute()
        if rows:
            self.sheets.spreadsheets().values().update(
                spreadsheetId=spreadsheet_id,
                range=f"'{tab}'!A1",
                valueInputOption="RAW",
                body={"values": rows},
            ).execute()
