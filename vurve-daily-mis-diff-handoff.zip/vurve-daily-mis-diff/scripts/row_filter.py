"""Row-name filter: decide which DAILY MIS rows to watch.

Keep only Sales, Flows, Expenses, Staff rows.
Skip rollups / totals / adjustments / balances.
"""
from __future__ import annotations

SKIP_PREFIXES = (
    "sub total",
    "total",
    "less:",
    "closing cash balance",
    "opening cash balance",
)


def should_watch(row_name: str) -> bool:
    """True if this row's changes should be captured."""
    if row_name is None:
        return False
    r = str(row_name).strip().lower()
    if not r:
        return False
    for p in SKIP_PREFIXES:
        if r.startswith(p):
            return False
    return True
