"""Read/write the hidden per-month state tab inside the master workbook.

State tab columns:
  Filename | Sheet Tab | Row Name | Column Name | Last Value

One row per watched cell. Rewritten only after a successful diff append,
so a crash mid-run leaves yesterday's state intact.
"""
from __future__ import annotations

from typing import Iterable

STATE_COLS = ["Filename", "Sheet Tab", "Row Name", "Column Name", "Last Value"]
SEP = "\x1f"  # unit separator, never appears in sheet text


def state_key(filename: str, tab: str, row_name: str, col_name: str) -> str:
    return SEP.join([filename, tab, row_name, col_name])


def _split(key: str) -> tuple[str, str, str, str]:
    parts = key.split(SEP)
    return (parts + ["", "", "", ""])[:4]


def load_state(client, master_id: str, state_tab: str) -> dict[str, str]:
    """Return {key: last_value} for every cell we watched last run.
    Empty dict if the tab doesn't exist yet (first run of a month)."""
    try:
        rows = client.read_values(master_id, state_tab)
    except Exception:
        return {}
    if not rows or [c for c in rows[0][:len(STATE_COLS)]] != STATE_COLS:
        return {}
    out: dict[str, str] = {}
    for r in rows[1:]:
        r = list(r) + [None] * (len(STATE_COLS) - len(r))
        filename, tab, row_name, col_name, last = r[:5]
        if not filename:
            continue
        out[state_key(str(filename), str(tab or ""),
                      str(row_name or ""), str(col_name or ""))] = (
            "" if last is None else str(last)
        )
    return out


def save_state(client, master_id: str, state_tab: str,
               snapshot: dict[str, str]) -> None:
    """Overwrite the state tab with `snapshot`."""
    rows: list[list] = [STATE_COLS]
    for k, v in snapshot.items():
        fn, tab, rn, cn = _split(k)
        rows.append([fn, tab, rn, cn, v])
    client.overwrite_tab(master_id, state_tab, rows)


def build_snapshot(per_outlet_grids: Iterable[tuple[str, dict]]) -> dict[str, str]:
    """Flatten [(filename, grid), ...] into {state_key: current_value}.

    Row Name    = column A of that row (or "" if blank).
    Column Name = row-1 header of that column if non-empty, else A1 ref.
    A cell counts as 'populated' if it has a value OR a note.
    """
    from drive_client import col_letter
    snap: dict[str, str] = {}
    for filename, grid in per_outlet_grids:
        values = grid.get("values") or []
        notes  = grid.get("notes") or []
        if not values:
            continue
        headers = values[0] if values else []
        for r_idx, row in enumerate(values, start=1):
            row_name = ""
            if r_idx > 1 and row and row[0] is not None:
                row_name = str(row[0]).strip()
            for c_idx, val in enumerate(row, start=1):
                note = None
                if r_idx - 1 < len(notes) and c_idx - 1 < len(notes[r_idx - 1]):
                    note = notes[r_idx - 1][c_idx - 1]
                if val is None and not note:
                    continue
                col_name = ""
                if c_idx - 1 < len(headers):
                    h = headers[c_idx - 1]
                    col_name = "" if h is None else str(h).strip()
                if not col_name:
                    col_name = f"{col_letter(c_idx)}{r_idx}"
                snap[state_key(filename, "DAILY MIS", row_name, col_name)] = (
                    "" if val is None else str(val)
                )
    return snap
