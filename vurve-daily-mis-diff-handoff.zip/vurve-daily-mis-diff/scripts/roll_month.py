"""On the first run of a new month (or when the master workbook exists but
the current month's tab is empty), create/seed UPDATES-<MON>-<YEAR> with a
baseline row per populated cell, and initialize the state tab.

Idempotent: if the tab already has data rows, this is a no-op.
Pass --force to wipe and re-seed.
"""
from __future__ import annotations

import sys
from datetime import datetime

from drive_client import DriveClient, load_config, col_letter
from state import build_snapshot, save_state, STATE_COLS
from row_filter import should_watch

HEADER = [
    "Pull Date & Time", "Filename", "Sheet Tab", "Column Name", "Row Name",
    "Old Value", "New Value", "Last Editor", "Comments / Notes",
    "Status", "Finance Remarks",
]


def current_month_tag(now: datetime) -> tuple[str, str]:
    return now.strftime("%b").upper(), str(now.year)


def month_has_data(client, master_id: str, tab: str) -> bool:
    """True if the tab has at least one row beyond the header."""
    if tab not in client.list_tabs(master_id):
        return False
    rows = client.read_values(master_id, tab)
    return len(rows) > 1


def run(force: bool = False) -> int:
    cfg = load_config()
    client = DriveClient(cfg)
    now = datetime.now()
    mon, year = current_month_tag(now)

    master_name = cfg["drive"]["master_workbook_name"]
    master = client.find_file(master_name, cfg["drive"]["master_folder_id"])
    if master is None:
        print(f"ERROR: master workbook '{master_name}' not found in "
              f"folder {cfg['drive']['master_folder_id']}", file=sys.stderr)
        return 1
    master_id = master["id"]

    tab_name  = cfg["output"]["tab_name_pattern"].format(mon=mon, year=year)
    state_tab = cfg["output"]["state_tab_pattern"].format(mon=mon, year=year)

    already_seeded = month_has_data(client, master_id, tab_name) and not force
    if already_seeded:
        print(f"[roll_month] {tab_name} already has data, skipping seed")
        return 0

    print(f"[roll_month] seeding baseline into {tab_name}")

    # Ensure the tab exists and (re)write the header row.
    client.ensure_tab(master_id, tab_name)
    client.overwrite_tab(master_id, tab_name, [HEADER])

    pull_ts = now.strftime("%Y-%m-%d %H:%M:%S")
    grids_for_snapshot: list[tuple[str, dict]] = []
    baseline_rows: list[list] = []

    for outlet in cfg["outlets"]:
        code = outlet["code"]
        mis_name = cfg["drive"]["mis_file_pattern"].format(
            code=code, mon=mon, year=year
        )
        f = client.find_file(mis_name, cfg["drive"]["mis_folder_id"])
        if f is None:
            print(f"[roll_month] {mis_name}: NOT FOUND, skipping", file=sys.stderr)
            continue

        grid = client.read_grid_with_notes(f["id"], cfg["drive"]["watch_tab"])
        grids_for_snapshot.append((mis_name, grid))

        values = grid["values"]
        notes  = grid["notes"]
        headers = values[0] if values else []

        for r_idx, row in enumerate(values, start=1):
            row_name = ""
            if r_idx > 1 and row and row[0] is not None:
                row_name = str(row[0]).strip()
            if r_idx > 1 and not should_watch(row_name):
                continue
            for c_idx, val in enumerate(row, start=1):
                note = None
                if r_idx - 1 < len(notes) and c_idx - 1 < len(notes[r_idx - 1]):
                    note = notes[r_idx - 1][c_idx - 1]
                if val is None and not note:
                    continue
                col_name = ""
                if c_idx - 1 < len(headers):
                    h = headers[c_idx - 1]
                    col_name = "" if h is None else str(h).strip()
                if not col_name:
                    col_name = f"{col_letter(c_idx)}{r_idx}"

                baseline_rows.append([
                    pull_ts,
                    mis_name,
                    cfg["drive"]["watch_tab"],
                    col_name,
                    row_name,
                    "" if val is None else val,  # Old Value
                    "",                          # New Value
                    "",                          # Last Editor
                    note or "",                  # Comments / Notes
                    "New",                       # Status
                    "",                          # Finance Remarks
                ])

    client.append_rows(master_id, tab_name, baseline_rows)
    save_state(client, master_id, state_tab, build_snapshot(grids_for_snapshot))
    print(f"[roll_month] wrote {len(baseline_rows)} baseline rows into {tab_name}")
    return 0


if __name__ == "__main__":
    sys.exit(run(force="--force" in sys.argv))
