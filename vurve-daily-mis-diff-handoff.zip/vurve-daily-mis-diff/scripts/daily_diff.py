"""Daily run: for every outlet, diff today's DAILY MIS grid against
yesterday's state, append changed-cell rows to UPDATES-<MON>-<YEAR>,
then advance the state tab.

Idempotent per day. If roll_month.py has just seeded the month and state
equals current, this run appends 0 rows (correct — nothing has changed yet).

Usage:
  python3 daily_diff.py            # append diffs (default)
  python3 daily_diff.py --dry-run  # print what would be appended, write nothing
"""
from __future__ import annotations

import sys
from datetime import datetime

from drive_client import DriveClient, load_config, col_letter
from state import build_snapshot, load_state, save_state, state_key
from row_filter import should_watch


def run(dry_run: bool = False) -> int:
    cfg = load_config()
    client = DriveClient(cfg)
    now = datetime.now()
    mon, year = now.strftime("%b").upper(), str(now.year)

    master = client.find_file(
        cfg["drive"]["master_workbook_name"],
        cfg["drive"]["master_folder_id"],
    )
    if master is None:
        print("ERROR: master workbook not found", file=sys.stderr)
        return 1
    master_id = master["id"]

    tab_name  = cfg["output"]["tab_name_pattern"].format(mon=mon, year=year)
    state_tab = cfg["output"]["state_tab_pattern"].format(mon=mon, year=year)

    if tab_name not in client.list_tabs(master_id):
        print(f"ERROR: {tab_name} not present. Run roll_month.py first.",
              file=sys.stderr)
        return 1

    prev_state = load_state(client, master_id, state_tab)
    if not prev_state:
        print(f"ERROR: {state_tab} empty or missing. Run roll_month.py first.",
              file=sys.stderr)
        return 1

    pull_ts = now.strftime("%Y-%m-%d %H:%M:%S")
    grids_for_snapshot: list[tuple[str, dict]] = []
    diff_rows: list[list] = []

    for outlet in cfg["outlets"]:
        code = outlet["code"]
        mis_name = cfg["drive"]["mis_file_pattern"].format(
            code=code, mon=mon, year=year
        )
        f = client.find_file(mis_name, cfg["drive"]["mis_folder_id"])
        if f is None:
            print(f"[daily_diff] {mis_name}: NOT FOUND, skipping", file=sys.stderr)
            continue

        grid = client.read_grid_with_notes(f["id"], cfg["drive"]["watch_tab"])
        grids_for_snapshot.append((mis_name, grid))

        values = grid["values"]
        notes  = grid["notes"]
        headers = values[0] if values else []

        for r_idx, row in enumerate(values, start=1):
            row_name = ""
            if r_idx > 1 and row and row[0] is not None:
                row_name = str(row[0]).strip()
            if r_idx > 1 and not should_watch(row_name):
                continue
            for c_idx, val in enumerate(row, start=1):
                note = None
                if r_idx - 1 < len(notes) and c_idx - 1 < len(notes[r_idx - 1]):
                    note = notes[r_idx - 1][c_idx - 1]
                if val is None and not note:
                    continue
                col_name = ""
                if c_idx - 1 < len(headers):
                    h = headers[c_idx - 1]
                    col_name = "" if h is None else str(h).strip()
                if not col_name:
                    col_name = f"{col_letter(c_idx)}{r_idx}"

                key = state_key(mis_name, cfg["drive"]["watch_tab"],
                                row_name, col_name)
                new_val = "" if val is None else str(val)
                old_val = prev_state.get(key)

                if old_val is None:
                    # cell newly appeared
                    diff_rows.append([
                        pull_ts, mis_name, cfg["drive"]["watch_tab"],
                        col_name, row_name,
                        "", new_val, "", note or "", "New", "",
                    ])
                elif old_val != new_val:
                    # value changed
                    diff_rows.append([
                        pull_ts, mis_name, cfg["drive"]["watch_tab"],
                        col_name, row_name,
                        old_val, new_val, "", note or "", "New", "",
                    ])
                # else: unchanged, emit nothing

    # Cells that disappeared since yesterday
    today_snapshot = build_snapshot(grids_for_snapshot)
    for key, old_val in prev_state.items():
        if key in today_snapshot:
            continue
        fn, tab, row_name, col_name = key.split("\x1f")
        diff_rows.append([
            pull_ts, fn, tab, col_name, row_name,
            old_val, "", "", "cell removed since last run", "New", "",
        ])

    if dry_run:
        print(f"[daily_diff] DRY RUN — {len(diff_rows)} rows would be appended")
        for r in diff_rows[:50]:
            print("  ", r)
        if len(diff_rows) > 50:
            print(f"   ... and {len(diff_rows) - 50} more")
        return 0

    client.append_rows(master_id, tab_name, diff_rows)
    save_state(client, master_id, state_tab, today_snapshot)
    print(f"[daily_diff] appended {len(diff_rows)} rows to {tab_name}")
    return 0


if __name__ == "__main__":
    sys.exit(run(dry_run="--dry-run" in sys.argv))
