#!/bin/bash
cd "$(dirname "$0")"
python3 build_tracker.py