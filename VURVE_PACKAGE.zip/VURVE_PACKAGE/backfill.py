"""
One-time backfill: builds cumulative outlet-day and employee-day history
from all Sales-Cash files in ~/VURVE/history/ plus the current file in ~/VURVE/in/.
"""
import os, re, html, glob, sys
from datetime import datetime
import pandas as pd
import numpy as np
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Border, Side, Alignment
from openpyxl.utils import get_column_letter

HERE = os.path.expanduser("~/VURVE")
HIST_DIR = os.path.join(HERE, "history")
IN_DIR = os.path.join(HERE, "in")
OUT_DIR = os.path.join(HERE, "out")

def find_sales_cash_in_in():
    hits = [h for h in glob.glob(os.path.join(IN_DIR, "Sales-Cash*.xls*"))
            if not os.path.basename(h).startswith("~$")]
    return sorted(hits)[0] if hits else None

def clean_name(n): return html.unescape(str(n)).strip()

def load_and_explode(path):
    raw = pd.read_excel(path, header=None)
    hdr = None
    for i in range(min(15, len(raw))):
        vals = [str(v).strip() for v in raw.iloc[i].tolist() if pd.notna(v)]
        if "Sale Date" in vals and "Center Name" in vals:
            hdr = i; break
    if hdr is None:
        print(f"  SKIP {os.path.basename(path)}: no header row found")
        return None
    df = pd.read_excel(path, header=hdr)
    df.columns = [str(c).strip() for c in df.columns]
    df = df[df['Center Name'].notna()].copy()
    df = df[df['Center Name'].astype(str).str.strip().str.lower() != 'total'].copy()
    df['Sale Date'] = pd.to_datetime(df['Sale Date'], format='%d-%m-%Y', errors='coerce')
    for col in ['Sales Collected (Exc.Tax)','Tax Collected','Sales Collected (Inc.Tax)',
                'Redeemed','Collected','Qty','Discount']:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col].astype(str).str.replace(',',''), errors='coerce').fillna(0)
    df = df[df['Sale Date'].notna()].copy()

    svc = df[df['Item Type'].astype(str).str.strip() == 'Service'].copy()
    lookup_rows = {}
    for _, r in svc.iterrows():
        nm = clean_name(r['Item Name'])
        qty = r['Qty'] if r['Qty'] else 1
        price = r['Sales Collected (Exc.Tax)'] / qty if qty else 0
        lookup_rows.setdefault(nm, []).append((r['Item Category'], r['Item Subcategory'], price))
    name_to_info = {}
    for nm, rows in lookup_rows.items():
        cats = [x[0] for x in rows if pd.notna(x[0])]
        subs = [x[1] for x in rows if pd.notna(x[1])]
        prices = [x[2] for x in rows if x[2] and x[2] > 0]
        name_to_info[nm] = {
            'Category': pd.Series(cats).mode().iloc[0] if cats else None,
            'Subcategory': pd.Series(subs).mode().iloc[0] if subs else None,
            'AvgPrice': float(np.mean(prices)) if prices else 0.0,
        }
    def parse_combo(name):
        parts = re.split(r'\s-\s{2}', clean_name(name), maxsplit=1)
        if len(parts) != 2: return None
        return [clean_name(s) for s in parts[1].split(',') if s.strip()]
    dp = df[df['Item Type'].astype(str).str.strip() == 'Day package'].copy()
    other = df[df['Item Type'].astype(str).str.strip() != 'Day package'].copy()
    exploded = []
    for _, row in dp.iterrows():
        services = parse_combo(row['Item Name'])
        if not services:
            exploded.append(row); continue
        weights, infos = [], []
        for s in services:
            info = name_to_info.get(s)
            if info and info['AvgPrice'] > 0:
                weights.append(info['AvgPrice']); infos.append(info)
            else:
                weights.append(None); infos.append(None)
        known = [w for w in weights if w is not None]
        fallback = (sum(known)/len(known)) if known else 1.0
        fw = [w if w is not None else fallback for w in weights]
        wsum = sum(fw) or 1.0
        for s, info, w in zip(services, infos, fw):
            share = w / wsum
            r = row.copy()
            r['Item Name'] = "[combo] " + s
            r['Item Category'] = info['Category'] if info and info['Category'] else row['Item Category']
            r['Item Subcategory'] = info['Subcategory'] if info and info['Subcategory'] else 'Not Specified'
            r['Item Type'] = 'Service'
            for col in ['Sales Collected (Exc.Tax)','Sales Collected (Inc.Tax)','Tax Collected',
                        'Collected','Qty','Redeemed']:
                r[col] = row[col] * share
            exploded.append(r)
    df_exploded = pd.concat([other, pd.DataFrame(exploded)], ignore_index=True) if exploded else other.copy()

    pt = df_exploded['Payment Type'].astype(str)
    net = pt.str.contains('Loyalty', case=False, na=False) | pt.str.contains('Gift Card', case=False, na=False)
    inc = df_exploded['Sales Collected (Inc.Tax)'].replace(0, np.nan)
    true_rev = (df_exploded['Collected'] * (df_exploded['Sales Collected (Exc.Tax)'] / inc)).fillna(0)
    df_exploded['Hybrid Rev'] = df_exploded['Sales Collected (Exc.Tax)'].where(~net, true_rev)
    df_exploded['ExcTax'] = df_exploded['Sales Collected (Exc.Tax)']
    return df_exploded

def norm(s):
    return re.sub(r'[^a-z]', '', str(s).lower()).replace('jubliee','jubilee')

CUT_SUBS   = {'Hair cut','HairCut','Cut & Styling'}
COLOR_SUBS = {'Hair Color','HAIR COLOR','HairColor'}
KER_SUBS   = {'Keratin','Hair Botox'}
FAC_SUBS   = {'Facial','Facials'}

files = sorted(glob.glob(os.path.join(HIST_DIR, "Sales-Cash_*.xlsx")))
cur = find_sales_cash_in_in()
if cur:
    files.append(cur)
print(f"Processing {len(files)} files")
print()

outlet_rows = []
emp_rows = []

for f in files:
    print(f"Reading {os.path.basename(f)}")
    dfx = load_and_explode(f)
    if dfx is None: continue

    dfx['day_key'] = dfx['Sale Date'].dt.strftime('%Y-%m-%d')
    dfx['outlet_key'] = dfx['Center Name'].astype(str).str.strip()
    dfx['emp_code'] = dfx['Sold By Code'].astype(str).str.strip() if 'Sold By Code' in dfx.columns else ''
    dfx['emp_name'] = dfx['Sold By'].astype(str).str.strip() if 'Sold By' in dfx.columns else ''

    for (outlet, day), grp in dfx.groupby(['outlet_key','day_key'], dropna=False):
        it = grp['Item Type'].astype(str).str.strip()
        pt = grp['Payment Type'].astype(str)
        is_red = pt.str.contains('Package - ', case=False, na=False)
        svc_mask = (it == 'Service') & (~is_red)
        svc_only = float(grp.loc[svc_mask, 'Hybrid Rev'].sum())
        pkgs = float(grp.loc[it == 'Package', 'Hybrid Rev'].sum())
        prod = float(grp.loc[it == 'Product', 'Sales Collected (Inc.Tax)'].sum())
        memb = float(grp.loc[it == 'Membership', 'ExcTax'].sum())
        outlet_rows.append([day, outlet, svc_only, pkgs, svc_only + pkgs, prod, memb,
                            svc_only + pkgs + prod + memb])

    dfx_valid = dfx[(dfx['emp_code'] != '') & (dfx['emp_code'].str.lower() != 'nan')].copy()
    inv = dfx_valid.drop_duplicates(subset=['Invoice No','emp_code','outlet_key','day_key']).copy()
    inv['is_new'] = inv['First Visit'].astype(str).str.strip().str.lower() == 'yes'

    for (code, name, outlet, day), grp in dfx_valid.groupby(['emp_code','emp_name','outlet_key','day_key'], dropna=False):
        it = grp['Item Type'].astype(str).str.strip()
        pt = grp['Payment Type'].astype(str)
        is_red = pt.str.contains('Package - ', case=False, na=False)
        subs = grp['Item Subcategory'].astype(str)
        svc_mask = (it == 'Service') & (~is_red)
        prod_mask = (it == 'Product')
        pkg_mask = (it == 'Package')
        mem_mask = (it == 'Membership')

        svc_only = float(grp.loc[svc_mask, 'Hybrid Rev'].sum())
        prod_ach = float(grp.loc[prod_mask, 'Sales Collected (Inc.Tax)'].sum())
        memb_sold = float(grp.loc[mem_mask, 'ExcTax'].sum())
        pkg_count = int(pkg_mask.sum())
        pkg_value = float(grp.loc[pkg_mask, 'Hybrid Rev'].sum())

        cut_ct   = int((subs.isin(CUT_SUBS)   & svc_mask).sum())
        color_ct = int((subs.isin(COLOR_SUBS) & svc_mask).sum())
        ker_ct   = int((subs.isin(KER_SUBS)   & svc_mask).sum())
        fac_ct   = int((subs.isin(FAC_SUBS)   & svc_mask).sum())
        prod_ct  = int(prod_mask.sum())

        inv_sub = inv[(inv['emp_code']==code) & (inv['outlet_key']==outlet) & (inv['day_key']==day)]
        new_g = int(inv_sub['is_new'].sum())
        exist_g = int((~inv_sub['is_new']).sum())

        emp_rows.append([day, outlet, name, pkg_count, pkg_value, svc_only, prod_ach, memb_sold,
                         svc_only + pkg_value + prod_ach + memb_sold,
                         cut_ct, color_ct, ker_ct, fac_ct, prod_ct, new_g, exist_g])

years = set(r[0][:4] for r in outlet_rows)
print()
print("Years found:", sorted(years))

NAVY = PatternFill('solid', fgColor='FF1F3864')
thin = Side(style='thin', color='BFBFBF')
BORDER = Border(left=thin, right=thin, top=thin, bottom=thin)
HDR_FONT = Font(name='Cambria', size=10, bold=True, color='FFFFFFFF')

def write_sheet(ws, headers, rows, widths):
    for i, h in enumerate(headers, start=1):
        c = ws.cell(row=1, column=i, value=h)
        c.fill = NAVY; c.font = HDR_FONT; c.border = BORDER
        c.alignment = Alignment(wrap_text=True, vertical='center')
    for r_i, r_data in enumerate(rows, start=2):
        for i, v in enumerate(r_data, start=1):
            cell = ws.cell(row=r_i, column=i, value=v)
            cell.border = BORDER
            if isinstance(v, (int, float)) and i >= 4:
                cell.number_format = '#,##0'
    for i, w in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.freeze_panes = 'A2'

for y in sorted(years):
    o_rows = [r for r in outlet_rows if r[0].startswith(y)]
    e_rows = [r for r in emp_rows if r[0].startswith(y)]

    wb = Workbook(); ws = wb.active; ws.title = 'Outlet Sales'
    headers_o = ['Date','Outlet','Services Only','Packages','Service ACH','Product ACH','Membership Sold','Total Sales']
    write_sheet(ws, headers_o, o_rows, [12,22,14,12,14,14,16,14])
    p_o = os.path.join(OUT_DIR, f"outlet_sales_history_{y}.xlsx")
    wb.save(p_o)
    print(f"Wrote {p_o} ({len(o_rows)} rows)")

    wb = Workbook(); ws = wb.active; ws.title = 'Employee Sales'
    headers_e = ['Date','Outlet','Staff','Packages','Packages Rs','Service','Product ACH',
                 'Membership Sold','Total Revenue','Cut Count','Color Count','Keratin Count',
                 'Facial Count','Product Count','New Guests','Old Guests']
    write_sheet(ws, headers_e, e_rows, [12,22,22,10,12,14,14,16,14,10,10,12,11,12,11,11])
    p_e = os.path.join(OUT_DIR, f"employee_history_{y}.xlsx")
    wb.save(p_e)
    print(f"Wrote {p_e} ({len(e_rows)} rows)")

print()
print("Backfill complete.")
