"""
VURVE Daily Sales Tracker builder.
Reads from ~/VURVE/in/, writes to ~/VURVE/out/dailysalestracker.xlsx
"""
import os, re, html, glob, sys, calendar
import pandas as pd
import numpy as np
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Border, Side, Alignment
from openpyxl.utils import get_column_letter

HERE = os.path.expanduser("~/VURVE")
IN_DIR = os.path.join(HERE, "in")
OUT_DIR = os.path.join(HERE, "out")
OUT_FILE = os.path.join(OUT_DIR, "dailysalestracker.xlsx")
os.makedirs(IN_DIR, exist_ok=True)
os.makedirs(OUT_DIR, exist_ok=True)

def find_file(patterns):
    for pat in patterns:
        hits = [h for h in glob.glob(os.path.join(IN_DIR, pat))
                if not os.path.basename(h).startswith("~$")]
        if hits:
            return sorted(hits)[0]
    return None

sales_cash_path = find_file(["Sales-Cash*.xls*", "sales-cash*.xls*", "SalesCash*.xls*"])
tgt_path         = find_file(["VURVE DAILY SALES TRACKER*.xls*", "*DAILY SALES TRACKER*.xls*"])
google_path      = find_file(["VURVE_Google_Reviews*.xls*", "*Google_Reviews*.xls*", "*Google Reviews*.xls*"])

if not sales_cash_path:
    print("ERROR: No Sales-Cash file found in", IN_DIR); sys.exit(1)
if not tgt_path:
    print("ERROR: No VURVE DAILY SALES TRACKER file found in", IN_DIR); sys.exit(1)

print("Sales-Cash :", os.path.basename(sales_cash_path))
print("TGT file   :", os.path.basename(tgt_path))
if google_path:
    print("Google file:", os.path.basename(google_path))
else:
    print("Google file: NOT FOUND - Google columns will be zero")

raw = pd.read_excel(sales_cash_path, header=None)
header_row = None
for i in range(min(15, len(raw))):
    vals = [str(v).strip() for v in raw.iloc[i].tolist() if pd.notna(v)]
    if "Sale Date" in vals and "Center Name" in vals:
        header_row = i; break
if header_row is None:
    print("ERROR: Could not find header row in Sales-Cash."); sys.exit(1)

df = pd.read_excel(sales_cash_path, header=header_row)
df.columns = [str(c).strip() for c in df.columns]
df = df[df['Center Name'].notna()].copy()
df = df[df['Center Name'].astype(str).str.strip().str.lower() != 'total'].copy()
df['Sale Date'] = pd.to_datetime(df['Sale Date'], format='%d-%m-%Y', errors='coerce')
for col in ['Sales Collected (Exc.Tax)','Tax Collected','Sales Collected (Inc.Tax)',
            'Redeemed','Collected','Qty','Discount']:
    df[col] = pd.to_numeric(df[col].astype(str).str.replace(',',''), errors='coerce').fillna(0)
df = df[df['Sale Date'].notna()].copy()
start_date = df['Sale Date'].min()
end_date   = df['Sale Date'].max()
print("Date range :", start_date.date(), "to", end_date.date())

def clean_name(n): return html.unescape(str(n)).strip()

svc = df[df['Item Type'].astype(str).str.strip() == 'Service'].copy()
lookup_rows = {}
for _, r in svc.iterrows():
    nm = clean_name(r['Item Name'])
    qty = r['Qty'] if r['Qty'] else 1
    price = r['Sales Collected (Exc.Tax)'] / qty if qty else 0
    lookup_rows.setdefault(nm, []).append((r['Item Category'], r['Item Subcategory'], price))
name_to_info = {}
for nm, rows in lookup_rows.items():
    cats = [x[0] for x in rows if pd.notna(x[0])]
    subs = [x[1] for x in rows if pd.notna(x[1])]
    prices = [x[2] for x in rows if x[2] and x[2] > 0]
    name_to_info[nm] = {
        'Category': pd.Series(cats).mode().iloc[0] if cats else None,
        'Subcategory': pd.Series(subs).mode().iloc[0] if subs else None,
        'AvgPrice': float(np.mean(prices)) if prices else 0.0,
    }

def parse_combo(name):
    parts = re.split(r'\s-\s{2}', clean_name(name), maxsplit=1)
    if len(parts) != 2: return None
    return [clean_name(s) for s in parts[1].split(',') if s.strip()]

dp    = df[df['Item Type'].astype(str).str.strip() == 'Day package'].copy()
other = df[df['Item Type'].astype(str).str.strip() != 'Day package'].copy()
exploded = []
for _, row in dp.iterrows():
    services = parse_combo(row['Item Name'])
    if not services:
        exploded.append(row); continue
    weights, infos = [], []
    for s in services:
        info = name_to_info.get(s)
        if info and info['AvgPrice'] > 0:
            weights.append(info['AvgPrice']); infos.append(info)
        else:
            weights.append(None); infos.append(None)
    known = [w for w in weights if w is not None]
    fallback = (sum(known)/len(known)) if known else 1.0
    fw = [w if w is not None else fallback for w in weights]
    wsum = sum(fw) or 1.0
    for s, info, w in zip(services, infos, fw):
        share = w / wsum
        r = row.copy()
        r['Item Name'] = "[combo] " + s
        r['Item Category']    = info['Category'] if info and info['Category'] else row['Item Category']
        r['Item Subcategory'] = info['Subcategory'] if info and info['Subcategory'] else 'Not Specified'
        r['Item Type'] = 'Service'
        for col in ['Sales Collected (Exc.Tax)','Sales Collected (Inc.Tax)','Tax Collected',
                    'Collected','Qty','Redeemed']:
            r[col] = row[col] * share
        exploded.append(r)
df_exploded = pd.concat([other, pd.DataFrame(exploded)], ignore_index=True) if exploded else other.copy()

pt = df_exploded['Payment Type'].astype(str)
net = pt.str.contains('Loyalty', case=False, na=False) | pt.str.contains('Gift Card', case=False, na=False)
inc = df_exploded['Sales Collected (Inc.Tax)'].replace(0, np.nan)
true_rev = (df_exploded['Collected'] * (df_exploded['Sales Collected (Exc.Tax)'] / inc)).fillna(0)
df_exploded['Hybrid Rev'] = df_exploded['Sales Collected (Exc.Tax)'].where(~net, true_rev).round(0)

def norm(s):
    return re.sub(r'[^a-z]', '', str(s).lower()).replace('jubliee','jubilee')
df_exploded['center_key'] = df_exploded['Center Name'].apply(lambda x: norm(str(x).replace('Vurve - ', '')))

tgt_xl = pd.ExcelFile(tgt_path)
target_month_abbr = end_date.strftime('%b').upper()
matching_tab = None
for tab in tgt_xl.sheet_names:
    if target_month_abbr in tab.upper().replace(' ', ''):
        matching_tab = tab; break
if matching_tab is None:
    matching_tab = tgt_xl.sheet_names[-1]
    print("WARN: No TGT tab matched month", target_month_abbr, "- using", matching_tab)
print("TGT tab    :", matching_tab)

tgt_raw = pd.read_excel(tgt_path, sheet_name=matching_tab, header=None)
hdr_idx = None
for i in range(min(15, len(tgt_raw))):
    vals = [str(v).strip().upper() for v in tgt_raw.iloc[i].tolist() if pd.notna(v)]
    if 'CENTER' in vals and any('SERVICE' in v for v in vals):
        hdr_idx = i; break
if hdr_idx is None:
    print("ERROR: Could not find header row in TGT tab."); sys.exit(1)

tgt = pd.read_excel(tgt_path, sheet_name=matching_tab, header=hdr_idx)
tgt.columns = [str(c).strip() for c in tgt.columns]

def find_col(cands):
    for c in tgt.columns:
        for cand in cands:
            if cand.upper() in c.upper(): return c
    return None

col_center  = find_col(['CENTER'])
col_service = find_col(['SERVICE'])
col_product = find_col(['PRODUCT'])
col_facial  = find_col(['FACIAL'])
col_keratin = find_col(['KERATIN'])
col_google  = find_col(['GOOGLE'])
if not all([col_center, col_service, col_product, col_facial, col_keratin, col_google]):
    print("ERROR: TGT tab missing a required column."); sys.exit(1)

tgt = tgt[tgt[col_center].notna()].copy()
tgt = tgt[~tgt[col_center].astype(str).str.upper().str.contains('TOTAL')].copy()
tgt = tgt[~tgt[col_center].astype(str).str.upper().str.strip().eq('CENTER')].copy()
tgt['center_key'] = tgt[col_center].apply(lambda x: norm(str(x).replace('Vurve - ', '')))
for c in [col_service, col_product, col_facial, col_keratin, col_google]:
    tgt[c] = pd.to_numeric(tgt[c].astype(str).str.replace(',',''), errors='coerce').fillna(0)
tgt_map = {}
for _, r in tgt.iterrows():
    tgt_map[r['center_key']] = {
        'Service TGT': float(r[col_service]),
        'Product TGT': float(r[col_product]),
        'Facial TGT': float(r[col_facial]),
        'Keratin+Botox TGT': float(r[col_keratin]),
        'Google Reviews TGT': float(r[col_google]),
    }

google_map = {}
if google_path:
    gxl = pd.ExcelFile(google_path)
    g_tab = None
    for tab in gxl.sheet_names:
        if target_month_abbr in tab.upper().replace(' ', ''):
            g_tab = tab; break
    if g_tab is None:
        g_tab = gxl.sheet_names[-1]
        print("WARN: No Google tab matched", target_month_abbr, "- using", g_tab)
    print("Google tab :", g_tab)
    gdf = pd.read_excel(google_path, sheet_name=g_tab)
    gdf.columns = [str(c).strip() for c in gdf.columns]
    gcol_outlet = gcol_reviews = gcol_negative = None
    for c in gdf.columns:
        cu = c.upper()
        if cu == 'OUTLET': gcol_outlet = c
        if 'REVIEWS COLLECTED' in cu: gcol_reviews = c
        if cu == 'NEGATIVE': gcol_negative = c
    if gcol_outlet and gcol_reviews and gcol_negative:
        gdf = gdf[~gdf[gcol_outlet].astype(str).str.upper().str.contains('TOTAL')].copy()
        for _, r in gdf.iterrows():
            name = str(r[gcol_outlet]).replace('Vurve Salon |','').strip()
            gv1 = pd.to_numeric(r[gcol_reviews], errors='coerce')
            gv2 = pd.to_numeric(r[gcol_negative], errors='coerce')
            google_map[norm(name)] = {
                'Google Reviews ACH': float(gv1) if pd.notna(gv1) else 0.0,
                'Negative Reviews': float(gv2) if pd.notna(gv2) else 0.0,
            }

ZONE_ORDER = [
    ('Bangalore', ['Vurve - Indira Nagar','Vurve - Sadashiva Nagar','Vurve - Jaya Nagar']),
    ('Chennai',   ['Vurve - Nungambakkam','Vurve - Alwarpet','Vurve - Kilpauk','Vurve - Annanagar',
                   'Vurve - T-Nagar','Vurve - Adyar','Vurve - Ashok Nagar','Vurve - Velachery',
                   'Vurve - ECR','Vurve - OMR']),
    ('Kochi',     ['Vurve - Kochi']),
    ('Hyderabad', ['Vurve - Jubilee Hills']),
]
CENTER_ORDER = [c for _, lst in ZONE_ORDER for c in lst]
ZONE_OF = {c: z for z, lst in ZONE_ORDER for c in lst}
def short_center(n): return n.replace('Vurve - ','').strip()

agg = {}
for center in CENTER_ORDER:
    key = norm(center.replace('Vurve - ', ''))
    sub = df_exploded[df_exploded['center_key'] == key]
    if sub.empty:
        svc_only = pkgs = svc_ach = prod_ach = memb = facial = keratin = 0.0
    else:
        it = sub['Item Type'].astype(str).str.strip()
        pt_local = sub['Payment Type'].astype(str)
        is_redemption = pt_local.str.contains('Package - ', case=False, na=False)
        standalone_service_mask = (it == 'Service') & (~is_redemption)
        svc_only  = round(float(sub.loc[standalone_service_mask, 'Hybrid Rev'].sum()))
        pkgs      = round(float(sub.loc[it == 'Package', 'Hybrid Rev'].sum()))
        svc_ach   = svc_only + pkgs
        prod_ach  = round(float(sub.loc[it == 'Product', 'Sales Collected (Inc.Tax)'].sum()))
        memb      = float(sub.loc[it == 'Membership', 'Hybrid Rev'].sum())
        subs      = sub['Item Subcategory'].astype(str)
        facial    = round(float(sub.loc[subs.isin(['Facial','Facials']), 'Hybrid Rev'].sum()))
        keratin   = round(float(sub.loc[subs.isin(['Keratin','Hair Botox']), 'Hybrid Rev'].sum()))
    inv = sub.drop_duplicates(subset=['Invoice No']) if not sub.empty else sub
    if not inv.empty:
        g = inv['Guest gender'].astype(str).str.strip().str.lower()
        male   = int((g == 'male').sum())
        female = int((g == 'female').sum())
        total_w = male + female + int((~g.isin(['male','female'])).sum())
    else:
        male = female = total_w = 0
    t = tgt_map.get(key, {})
    g = google_map.get(key, {})
    agg[center] = {
        'Service TGT': t.get('Service TGT', 0), 'Service ACH': svc_ach,
        'Services Only': svc_only, 'Packages': pkgs,
        'Product TGT': t.get('Product TGT', 0), 'Product ACH': prod_ach,
        'Membership Sold': memb,
        'Facial TGT': t.get('Facial TGT', 0), 'Facial ACH': facial,
        'Keratin+Botox TGT': t.get('Keratin+Botox TGT', 0), 'Keratin+Botox ACH': keratin,
        'Google Reviews TGT': t.get('Google Reviews TGT', 0),
        'Google Reviews ACH': g.get('Google Reviews ACH', 0),
        'Negative Reviews': g.get('Negative Reviews', 0),
        'Male Walkins': male, 'Female Walkins': female, 'Total Walkins': total_w,
    }

BRAND = {k: sum(agg[c][k] for c in CENTER_ORDER) for k in agg[CENTER_ORDER[0]].keys()}
days_in_month = calendar.monthrange(end_date.year, end_date.month)[1]
DAYS_REMAINING = days_in_month - end_date.day

wb = Workbook()
NAVY = PatternFill('solid', fgColor='FF1F3864')
TOTAL_FILL = PatternFill('solid', fgColor='FFD9D9D9')
thin = Side(style='thin', color='BFBFBF')
BORDER = Border(left=thin, right=thin, top=thin, bottom=thin)
HDR_FONT = Font(name='Cambria', size=10, bold=True, color='FFFFFFFF')

def style_header(ws, row, cols):
    for c in cols:
        cell = ws.cell(row=row, column=c)
        cell.fill = NAVY; cell.font = HDR_FONT
        cell.border = BORDER
        cell.alignment = Alignment(wrap_text=True, vertical='center')

def style_border_range(ws, r1, r2, c1, c2):
    for r in range(r1, r2+1):
        for c in range(c1, c2+1):
            ws.cell(row=r, column=c).border = BORDER

ws = wb.active; ws.title = 'Summary'
ws.column_dimensions['A'].width = 78
ws.column_dimensions['B'].width = 18
ws['A1'] = f"VURVE DAILY SALES TRACKER (Sales-Cash build) - {start_date.strftime('%d-%b-%Y')} to {end_date.strftime('%d-%b-%Y')}"
ws['A1'].font = Font(bold=True, size=11, color='FF1F3864')
ws['A2'] = f"Data window: {start_date.strftime('%d-%b-%Y')} - {end_date.strftime('%d-%b-%Y')}. Hybrid Rev basis applied."
rows = [
    ('Metric','Value'),
    ('Org-wide Service ACH (Services Only + Packages, Hybrid Rev basis)', BRAND['Service ACH']),
    ('  Services Only', BRAND['Services Only']),
    ('  Packages', BRAND['Packages']),
    ('Service TGT (15 outlets)', BRAND['Service TGT']),
    ('Retail Product Sales / Product ACH (Inc.Tax, 15 outlets)', BRAND['Product ACH']),
    ('Product TGT (15 outlets)', BRAND['Product TGT']),
    ('Membership Sales (Hybrid Rev, 15 outlets)', BRAND['Membership Sold']),
    ('Facial ACH (Hybrid Rev basis)', BRAND['Facial ACH']),
    ('Facial TGT', BRAND['Facial TGT']),
    ('Keratin+Botox ACH (Hybrid Rev basis)', BRAND['Keratin+Botox ACH']),
    ('Keratin+Botox TGT', BRAND['Keratin+Botox TGT']),
    ('Google Reviews TGT', BRAND['Google Reviews TGT']),
    ('Google Reviews ACH', BRAND['Google Reviews ACH']),
    ('Negative Reviews', BRAND['Negative Reviews']),
    ('Total Walk-ins - Male', BRAND['Male Walkins']),
    ('Total Walk-ins - Female', BRAND['Female Walkins']),
    ('Total Walk-ins - Total', BRAND['Total Walkins']),
    ('Days Remaining in Month', DAYS_REMAINING),
]
r0 = 4
for i, (k, v) in enumerate(rows):
    ws.cell(row=r0+i, column=1, value=k)
    ws.cell(row=r0+i, column=2, value=round(v) if isinstance(v, (int, float)) else v)
style_header(ws, r0, [1,2])
for i in range(1, len(rows)):
    ws.cell(row=r0+i, column=2).number_format = '#,##0'
style_border_range(ws, r0+1, r0+len(rows)-1, 1, 2)

ws = wb.create_sheet('Daily Sales Tracker')
ws['A1'] = f"VURVE DAILY SALES TRACKER (Sales-Cash build) - {start_date.strftime('%d-%b-%Y')} to {end_date.strftime('%d-%b-%Y')}"
ws['F1'] = 'Days Remaining:'; ws['F1'].font = Font(bold=True)
ws['G1'] = DAYS_REMAINING
headers = ['Zone','Center',
    'Service TGT','Service ACH','Service %ACH','Service Balance2Go','Service TGT for the Day',
    'Services Only','Packages',
    'Product TGT','Product ACH','Product %ACH','Product Balance2Go','Product TGT for the Day',
    'Membership Sold',
    'Facial TGT','Facial ACH','Facial %ACH','Facial Balance2Go','Facial TGT for the Day',
    'Keratin+Botox TGT','Keratin+Botox ACH','Keratin+Botox %ACH','Keratin+Botox Balance2Go','Keratin+Botox TGT for the Day',
    'Google Reviews TGT','Google Reviews ACH','Google Reviews %ACH','Google Reviews Balance2Go','Google Reviews TGT for the Day',
    'Negative Reviews','Male Walkins','Female Walkins','Total Walkins']
hdr_row = 3
for i, h in enumerate(headers, start=1): ws.cell(row=hdr_row, column=i, value=h)
fill_map = {
    (3,4,5,6,7,8,9): PatternFill('solid', fgColor='FF2F5597'),
    (10,11,12,13,14): PatternFill('solid', fgColor='FF548235'),
    (15,): PatternFill('solid', fgColor='FFBF8F00'),
    (16,17,18,19,20): PatternFill('solid', fgColor='FFC55A11'),
    (21,22,23,24,25): PatternFill('solid', fgColor='FF7030A0'),
    (26,27,28,29,30): PatternFill('solid', fgColor='FF2E75B6'),
    (31,): PatternFill('solid', fgColor='FF595959'),
    (32,33,34): PatternFill('solid', fgColor='FF3A3838'),
    (1,2): NAVY}
for cols, fill in fill_map.items():
    for c in cols:
        cell = ws.cell(row=hdr_row, column=c)
        cell.fill = fill; cell.font = HDR_FONT; cell.border = BORDER
        cell.alignment = Alignment(wrap_text=True, vertical='center')
ws.row_dimensions[hdr_row].height = 42
def pct(a,t): return (a/t) if t else 0
def b2g(a,t): return t - a
def tgtd(b): return (b/DAYS_REMAINING) if DAYS_REMAINING else 0
r = hdr_row + 1
for center in CENTER_ORDER:
    a = agg[center]
    ws.cell(row=r, column=1, value=ZONE_OF[center])
    ws.cell(row=r, column=2, value=center)
    vals = [a['Service TGT'], a['Service ACH'], pct(a['Service ACH'], a['Service TGT']),
            b2g(a['Service ACH'], a['Service TGT']), tgtd(b2g(a['Service ACH'], a['Service TGT'])),
            a['Services Only'], a['Packages'],
            a['Product TGT'], a['Product ACH'], pct(a['Product ACH'], a['Product TGT']),
            b2g(a['Product ACH'], a['Product TGT']), tgtd(b2g(a['Product ACH'], a['Product TGT'])),
            a['Membership Sold'],
            a['Facial TGT'], a['Facial ACH'], pct(a['Facial ACH'], a['Facial TGT']),
            b2g(a['Facial ACH'], a['Facial TGT']), tgtd(b2g(a['Facial ACH'], a['Facial TGT'])),
            a['Keratin+Botox TGT'], a['Keratin+Botox ACH'], pct(a['Keratin+Botox ACH'], a['Keratin+Botox TGT']),
            b2g(a['Keratin+Botox ACH'], a['Keratin+Botox TGT']), tgtd(b2g(a['Keratin+Botox ACH'], a['Keratin+Botox TGT'])),
            a['Google Reviews TGT'], a['Google Reviews ACH'], pct(a['Google Reviews ACH'], a['Google Reviews TGT']),
            b2g(a['Google Reviews ACH'], a['Google Reviews TGT']), tgtd(b2g(a['Google Reviews ACH'], a['Google Reviews TGT'])),
            a['Negative Reviews'], a['Male Walkins'], a['Female Walkins'], a['Total Walkins']]
    for i, v in enumerate(vals, start=3):
        if '%ACH' in headers[i-1]:
            ws.cell(row=r, column=i, value=v)
        else:
            ws.cell(row=r, column=i, value=round(v) if isinstance(v, (int, float)) and v == v else v)
    r += 1
ws.cell(row=r, column=1, value='BRAND'); ws.cell(row=r, column=2, value='TOTAL')
b = BRAND
brand_vals = [b['Service TGT'], b['Service ACH'], pct(b['Service ACH'], b['Service TGT']),
    b2g(b['Service ACH'], b['Service TGT']), tgtd(b2g(b['Service ACH'], b['Service TGT'])),
    b['Services Only'], b['Packages'],
    b['Product TGT'], b['Product ACH'], pct(b['Product ACH'], b['Product TGT']),
    b2g(b['Product ACH'], b['Product TGT']), tgtd(b2g(b['Product ACH'], b['Product TGT'])),
    b['Membership Sold'],
    b['Facial TGT'], b['Facial ACH'], pct(b['Facial ACH'], b['Facial TGT']),
    b2g(b['Facial ACH'], b['Facial TGT']), tgtd(b2g(b['Facial ACH'], b['Facial TGT'])),
    b['Keratin+Botox TGT'], b['Keratin+Botox ACH'], pct(b['Keratin+Botox ACH'], b['Keratin+Botox TGT']),
    b2g(b['Keratin+Botox ACH'], b['Keratin+Botox TGT']), tgtd(b2g(b['Keratin+Botox ACH'], b['Keratin+Botox TGT'])),
    b['Google Reviews TGT'], b['Google Reviews ACH'], pct(b['Google Reviews ACH'], b['Google Reviews TGT']),
    b2g(b['Google Reviews ACH'], b['Google Reviews TGT']), tgtd(b2g(b['Google Reviews ACH'], b['Google Reviews TGT'])),
    b['Negative Reviews'], b['Male Walkins'], b['Female Walkins'], b['Total Walkins']]
for i, v in enumerate(brand_vals, start=3):
    if '%ACH' in headers[i-1]:
        ws.cell(row=r, column=i, value=v)
    else:
        ws.cell(row=r, column=i, value=round(v) if isinstance(v, (int, float)) and v == v else v)
for c in range(1, len(headers)+1):
    cell = ws.cell(row=r, column=c); cell.fill = TOTAL_FILL
    cell.font = Font(bold=True); cell.border = BORDER
for rr in range(hdr_row+1, r+1):
    for cc in range(3, len(headers)+1):
        if '%ACH' in headers[cc-1]: ws.cell(row=rr, column=cc).number_format = '0%'
        else: ws.cell(row=rr, column=cc).number_format = '#,##0'
style_border_range(ws, hdr_row+1, r, 1, len(headers))
ws.column_dimensions['A'].width = 11
ws.column_dimensions['B'].width = 24
for col in range(3, len(headers)+1): ws.column_dimensions[get_column_letter(col)].width = 13
ws.column_dimensions['C'].width = 14; ws.column_dimensions['D'].width = 8.71
ws.freeze_panes = 'C4'

ws = wb.create_sheet('Service Category')
for col, w in zip(['A','B','C','D','E','F','G','H','I'],[30,16,13.29,11.43,8.71,11.14,12.86,8.71,13]):
    ws.column_dimensions[col].width = w
def section_title(ws, r, text):
    ws.cell(row=r, column=1, value=text).font = Font(bold=True, size=11, color='FF1F3864')
def table_header(ws, r, labels):
    for i, lab in enumerate(labels, start=1): ws.cell(row=r, column=i, value=lab)
    style_header(ws, r, list(range(1, len(labels)+1)))
def total_row(ws, r, vals):
    for i, v in enumerate(vals, start=1):
        cell = ws.cell(row=r, column=i, value=v)
        cell.fill = TOTAL_FILL; cell.font = Font(bold=True); cell.border = BORDER

r = 1
section_title(ws, r, f"1. Org Rollup by Category (Hybrid Rev basis) - {start_date.strftime('%d-%b-%Y')} to {end_date.strftime('%d-%b-%Y')}")
r += 1
table_header(ws, r, ['Category','Quantity','Hybrid Rev Sales']); r += 1
cat_roll = df_exploded.groupby('Item Category').agg(Qty=('Qty','sum'), Rev=('Hybrid Rev','sum')).reset_index().sort_values('Rev', ascending=False)
for _, row in cat_roll.iterrows():
    ws.cell(row=r, column=1, value=str(row['Item Category']))
    ws.cell(row=r, column=2, value=round(row['Qty'])).number_format = '#,##0'
    ws.cell(row=r, column=3, value=round(row['Rev'])).number_format = '#,##0'
    for c in range(1,4): ws.cell(row=r, column=c).border = BORDER
    r += 1
total_row(ws, r, ['TOTAL', cat_roll['Qty'].sum(), cat_roll['Rev'].sum()]); r += 3

section_title(ws, r, "2. Facials (Megan vs Regular) & Keratin+Botox Rollup by Center (Hybrid Rev basis)"); r += 1
table_header(ws, r, ['Center','Megan Facial Qty','Megan Facial Hybrid Rev','Regular Facial Qty','Regular Facial Hybrid Rev','Facial Total Qty','Facial Total Hybrid Rev']); r += 1
totals = [0]*6
for center in CENTER_ORDER:
    key = norm(center.replace('Vurve - ', ''))
    sub = df_exploded[(df_exploded['center_key'] == key) & (df_exploded['Item Subcategory'].astype(str).isin(['Facial','Facials']))]
    megan = sub[sub['Item Name'].astype(str).str.contains('megan', case=False, na=False)]
    reg = sub[~sub['Item Name'].astype(str).str.contains('megan', case=False, na=False)]
    row = [center, round(megan['Qty'].sum()), round(megan['Hybrid Rev'].sum()), round(reg['Qty'].sum()), round(reg['Hybrid Rev'].sum()), round(sub['Qty'].sum()), round(sub['Hybrid Rev'].sum())]
    for i, v in enumerate(row[1:]): totals[i] += v
    for i, v in enumerate(row, start=1):
        cell = ws.cell(row=r, column=i, value=v)
        if i > 1: cell.number_format = '#,##0'
        cell.border = BORDER
    r += 1
total_row(ws, r, ['TOTAL'] + totals); r += 3

section_title(ws, r, "3. Key Pillars - Color, Cut, Facials, HairSpa, Keratin by Center (Hybrid Rev basis)"); r += 1
table_header(ws, r, ['Center','Color','Cut','Facials','HairSpa','Keratin','Hair Rituals (unmapped - FYI)']); r += 1
COLOR = ['Hair Color','HAIR COLOR','HairColor']; CUT = ['Hair cut','HairCut','Cut & Styling']
FAC = ['Facial','Facials']; HSPA = ['Hair Spa']; KER = ['Keratin','Hair Botox']; HRIT = ['Hair Rituals']
totals = [0]*6
for center in CENTER_ORDER:
    key = norm(center.replace('Vurve - ', '')); sub = df_exploded[df_exploded['center_key'] == key]
    subs = sub['Item Subcategory'].astype(str)
    vals = [round(float(sub.loc[subs.isin(COLOR),'Hybrid Rev'].sum())),
            round(float(sub.loc[subs.isin(CUT),'Hybrid Rev'].sum())),
            round(float(sub.loc[subs.isin(FAC),'Hybrid Rev'].sum())),
            round(float(sub.loc[subs.isin(HSPA),'Hybrid Rev'].sum())),
            round(float(sub.loc[subs.isin(KER),'Hybrid Rev'].sum())),
            round(float(sub.loc[subs.isin(HRIT),'Hybrid Rev'].sum()))]
    for i, v in enumerate(vals): totals[i] += v
    ws.cell(row=r, column=1, value=center).border = BORDER
    for i, v in enumerate(vals, start=2):
        cell = ws.cell(row=r, column=i, value=v); cell.number_format = '#,##0'; cell.border = BORDER
    r += 1
total_row(ws, r, ['TOTAL'] + totals); r += 1
ws.cell(row=r, column=1, value="FLAG: Hair Spa and Hair Rituals are distinct subcategories in Sales-Cash; Hair Rituals shown for reference only.").font = Font(italic=True, size=9)
r += 3

section_title(ws, r, "4. Detail Matrix - Quantity (top 20 subcategories + Bridal) x Center"); r += 1
short_names = [short_center(c) for c in CENTER_ORDER]
table_header(ws, r, ['Subcategory'] + short_names + ['Total']); r += 1
qty_by_sub = df_exploded.pivot_table(index='Item Subcategory', columns='center_key', values='Qty', aggfunc='sum', fill_value=0)
qty_by_sub['Total'] = qty_by_sub.sum(axis=1)
qty_by_sub = qty_by_sub.sort_values('Total', ascending=False)
top = qty_by_sub.head(20)
for force in ['Not Specified','Bridal']:
    if force in qty_by_sub.index and force not in top.index:
        top = pd.concat([top, qty_by_sub.loc[[force]]])
for sub_name, row in top.iterrows():
    ws.cell(row=r, column=1, value=str(sub_name)).border = BORDER
    for i, c in enumerate(CENTER_ORDER, start=2):
        val = row.get(norm(c.replace('Vurve - ', '')), 0)
        cell = ws.cell(row=r, column=i, value=round(float(val))); cell.number_format = '#,##0'; cell.border = BORDER
    cell = ws.cell(row=r, column=len(CENTER_ORDER)+2, value=round(float(row['Total'])))
    cell.number_format = '#,##0'; cell.border = BORDER
    r += 1
tot_vals = ['TOTAL'] + [float(qty_by_sub[norm(c)].sum()) if norm(c) in qty_by_sub.columns else 0 for c in CENTER_ORDER] + [float(qty_by_sub['Total'].sum())]
total_row(ws, r, tot_vals); r += 3

section_title(ws, r, "5. Detail Matrix - Hybrid Rev Sales (top 20 subcategories + Bridal) x Center"); r += 1
table_header(ws, r, ['Subcategory'] + short_names + ['Total']); r += 1
rev_by_sub = df_exploded.pivot_table(index='Item Subcategory', columns='center_key', values='Hybrid Rev', aggfunc='sum', fill_value=0)
rev_by_sub['Total'] = rev_by_sub.sum(axis=1)
rev_by_sub = rev_by_sub.sort_values('Total', ascending=False)
top = rev_by_sub.head(20)
for force in ['Not Specified','Bridal']:
    if force in rev_by_sub.index and force not in top.index:
        top = pd.concat([top, rev_by_sub.loc[[force]]])
for sub_name, row in top.iterrows():
    ws.cell(row=r, column=1, value=str(sub_name)).border = BORDER
    for i, c in enumerate(CENTER_ORDER, start=2):
        val = row.get(norm(c.replace('Vurve - ', '')), 0)
        cell = ws.cell(row=r, column=i, value=round(float(val))); cell.number_format = '#,##0'; cell.border = BORDER
    cell = ws.cell(row=r, column=len(CENTER_ORDER)+2, value=round(float(row['Total'])))
    cell.number_format = '#,##0'; cell.border = BORDER
    r += 1
tot_vals = ['TOTAL'] + [float(rev_by_sub[norm(c)].sum()) if norm(c) in rev_by_sub.columns else 0 for c in CENTER_ORDER] + [float(rev_by_sub['Total'].sum())]
total_row(ws, r, tot_vals)

ws = wb.create_sheet('Retail Product Sales')
for col, w in zip(['A','B','C'], [30,16,8.71]): ws.column_dimensions[col].width = w
for col in ['D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T']:
    ws.column_dimensions[col].width = 13
prod = df_exploded[df_exploded['Item Type'].astype(str).str.strip() == 'Product'].copy()
r = 1
section_title(ws, r, f"1. Org Rollup by Brand (Item Type=Product, Sales Collected Inc.Tax) - {start_date.strftime('%d-%b-%Y')} to {end_date.strftime('%d-%b-%Y')}"); r += 1
table_header(ws, r, ['Brand','Quantity','Sales (Inc.Tax)']); r += 1
brand_roll = prod.groupby('Business Unit').agg(Qty=('Qty','sum'), Sales=('Sales Collected (Inc.Tax)','sum')).reset_index().sort_values('Sales', ascending=False)
for _, row in brand_roll.iterrows():
    ws.cell(row=r, column=1, value=str(row['Business Unit'])).border = BORDER
    c = ws.cell(row=r, column=2, value=round(row['Qty'])); c.number_format = '#,##0'; c.border = BORDER
    c = ws.cell(row=r, column=3, value=round(row['Sales'])); c.number_format = '#,##0'; c.border = BORDER
    r += 1
total_row(ws, r, ['TOTAL', round(brand_roll['Qty'].sum()), round(brand_roll['Sales'].sum())]); r += 3

section_title(ws, r, "2. Sales (Inc.Tax) by Brand x Center (Product only)"); r += 1
table_header(ws, r, ['Brand'] + short_names + ['Total']); r += 1
sales_pivot = prod.pivot_table(index='Business Unit', columns='center_key', values='Sales Collected (Inc.Tax)', aggfunc='sum', fill_value=0)
sales_pivot['Total'] = sales_pivot.sum(axis=1)
sales_pivot = sales_pivot.reindex(brand_roll['Business Unit'].tolist())
for brand, row in sales_pivot.iterrows():
    ws.cell(row=r, column=1, value=str(brand)).border = BORDER
    for i, c in enumerate(CENTER_ORDER, start=2):
        val = row.get(norm(c.replace('Vurve - ', '')), 0)
        cell = ws.cell(row=r, column=i, value=round(float(val))); cell.number_format = '#,##0'; cell.border = BORDER
    cell = ws.cell(row=r, column=len(CENTER_ORDER)+2, value=round(float(row['Total'])))
    cell.number_format = '#,##0'; cell.border = BORDER
    r += 1
tot = ['TOTAL'] + [round(float(sales_pivot[norm(c)].sum())) if norm(c) in sales_pivot.columns else 0 for c in CENTER_ORDER] + [round(float(sales_pivot['Total'].sum()))]
total_row(ws, r, tot); r += 3

section_title(ws, r, "3. Quantity by Brand x Center (Product only)"); r += 1
table_header(ws, r, ['Brand'] + short_names + ['Total']); r += 1
qty_pivot = prod.pivot_table(index='Business Unit', columns='center_key', values='Qty', aggfunc='sum', fill_value=0)
qty_pivot['Total'] = qty_pivot.sum(axis=1)
qty_pivot = qty_pivot.reindex(brand_roll['Business Unit'].tolist())
for brand, row in qty_pivot.iterrows():
    ws.cell(row=r, column=1, value=str(brand)).border = BORDER
    for i, c in enumerate(CENTER_ORDER, start=2):
        val = row.get(norm(c.replace('Vurve - ', '')), 0)
        cell = ws.cell(row=r, column=i, value=round(float(val))); cell.number_format = '#,##0'; cell.border = BORDER
    cell = ws.cell(row=r, column=len(CENTER_ORDER)+2, value=round(float(row['Total'])))
    cell.number_format = '#,##0'; cell.border = BORDER
    r += 1
tot = ['TOTAL'] + [round(float(qty_pivot[norm(c)].sum())) if norm(c) in qty_pivot.columns else 0 for c in CENTER_ORDER] + [round(float(qty_pivot['Total'].sum()))]
total_row(ws, r, tot)

# ---------- Employee Performance sheet ----------
ws_emp = wb.create_sheet('Employee Performance')
headers_emp = ['Date','Outlet','Staff','Sold By','Packages','Service','Product ACH','Membership Sold',
               'Total Revenue','Cut Count','Color Count','Keratin Count','Facial Count','Product Count',
               'New Guests','Old Guests']
for i, h in enumerate(headers_emp, start=1):
    ws_emp.cell(row=1, column=i, value=h)
style_header(ws_emp, 1, list(range(1, len(headers_emp)+1)))

CUT_SUBS   = {'Hair cut','HairCut','Cut & Styling'}
COLOR_SUBS = {'Hair Color','HAIR COLOR','HairColor'}
KER_SUBS   = {'Keratin','Hair Botox'}
FAC_SUBS   = {'Facial','Facials'}

emp_df = df_exploded.copy()
emp_df['day_key']    = emp_df['Sale Date'].dt.strftime('%Y-%m-%d')
emp_df['outlet_key'] = emp_df['Center Name'].astype(str).str.strip()
emp_df['emp_code']   = emp_df['Sold By Code'].astype(str).str.strip()
emp_df['emp_name']   = emp_df['Sold By'].astype(str).str.strip()
emp_df = emp_df[(emp_df['emp_code'] != '') & (emp_df['emp_code'].str.lower() != 'nan')].copy()

inv_emp = emp_df.drop_duplicates(subset=['Invoice No','emp_code','outlet_key','day_key']).copy()
inv_emp['is_new'] = inv_emp['First Visit'].astype(str).str.strip().str.lower() == 'yes'

rows_out = []
grouped = emp_df.groupby(['emp_code','emp_name','outlet_key','day_key'], dropna=False)
for (code, name, outlet, day), grp in grouped:
    it = grp['Item Type'].astype(str).str.strip()
    pt = grp['Payment Type'].astype(str)
    is_redemption = pt.str.contains('Package - ', case=False, na=False)
    subs = grp['Item Subcategory'].astype(str)

    svc_mask  = (it == 'Service') & (~is_redemption)
    prod_mask = (it == 'Product')
    pkg_mask  = (it == 'Package')
    mem_mask  = (it == 'Membership')

    svc_only  = float(grp.loc[svc_mask, 'Hybrid Rev'].sum())
    prod_ach  = float(grp.loc[prod_mask, 'Sales Collected (Inc.Tax)'].sum())
    memb_sold = float(grp.loc[mem_mask, 'Hybrid Rev'].sum())
    pkg_count = int(pkg_mask.sum())
    pkg_value = float(grp.loc[pkg_mask, 'Hybrid Rev'].sum())

    cut_ct   = int((subs.isin(CUT_SUBS)   & svc_mask).sum())
    color_ct = int((subs.isin(COLOR_SUBS) & svc_mask).sum())
    ker_ct   = int((subs.isin(KER_SUBS)   & svc_mask).sum())
    fac_ct   = int((subs.isin(FAC_SUBS)   & svc_mask).sum())
    prod_ct  = int(prod_mask.sum())

    inv_sub = inv_emp[(inv_emp['emp_code']==code) & (inv_emp['outlet_key']==outlet) & (inv_emp['day_key']==day)]
    new_g   = int(inv_sub['is_new'].sum())
    exist_g = int((~inv_sub['is_new']).sum())

    rows_out.append([day, outlet, name, code, pkg_count, svc_only, prod_ach, memb_sold,
                     svc_only + pkg_value + prod_ach, cut_ct, color_ct, ker_ct, fac_ct, prod_ct,
                     new_g, exist_g])

rows_out.sort(key=lambda x: (str(x[3]), str(x[1]), str(x[0])))

rr = 2
for r_data in rows_out:
    for i, v in enumerate(r_data, start=1):
        v = round(v) if isinstance(v, (int, float)) and v == v else v
        cell = ws_emp.cell(row=rr, column=i, value=v)
        cell.border = BORDER
        if i in (5,6,7,8,9,10,11,12,13,14,15,16):
            cell.number_format = '#,##0'
    rr += 1

widths_emp = [12,22,22,12,10,14,14,16,14,10,10,12,11,12,11,11]
for i, w in enumerate(widths_emp, start=1):
    ws_emp.column_dimensions[get_column_letter(i)].width = w
ws_emp.freeze_panes = 'A2'


# ---------- Update cumulative history files ----------
def update_history_files(dfx, start_date, end_date):
    from openpyxl import load_workbook
    OUT = OUT_DIR if 'OUT_DIR' in globals() else os.path.expanduser("~/VURVE/out")
    year = end_date.strftime('%Y')

    dfx = dfx.copy()
    dfx['day_key'] = dfx['Sale Date'].dt.strftime('%Y-%m-%d')
    dfx['outlet_key'] = dfx['Center Name'].astype(str).str.strip()
    dfx['emp_code'] = dfx['Sold By Code'].astype(str).str.strip() if 'Sold By Code' in dfx.columns else ''
    dfx['emp_name'] = dfx['Sold By'].astype(str).str.strip() if 'Sold By' in dfx.columns else ''

    # current month dates only
    month_prefix = end_date.strftime('%Y-%m')
    cur_dates = set(d for d in dfx['day_key'].unique() if str(d).startswith(month_prefix))
    print(f"History: refreshing {len(cur_dates)} dates in {month_prefix}")

    CUT_S   = {'Hair cut','HairCut','Cut & Styling'}
    COLOR_S = {'Hair Color','HAIR COLOR','HairColor'}
    KER_S   = {'Keratin','Hair Botox'}
    FAC_S   = {'Facial','Facials'}

    # build outlet rows
    o_rows = []
    for (outlet, day), grp in dfx.groupby(['outlet_key','day_key'], dropna=False):
        it = grp['Item Type'].astype(str).str.strip()
        pt = grp['Payment Type'].astype(str)
        is_red = pt.str.contains('Package - ', case=False, na=False)
        svc_mask = (it == 'Service') & (~is_red)
        svc_only = float(grp.loc[svc_mask, 'Hybrid Rev'].sum())
        pkgs     = float(grp.loc[it == 'Package', 'Hybrid Rev'].sum())
        prod     = float(grp.loc[it == 'Product', 'Sales Collected (Inc.Tax)'].sum())
        memb     = round(float(grp.loc[it == 'Membership', 'Sales Collected (Exc.Tax)'].sum()))
        o_rows.append([day, outlet, svc_only, pkgs, svc_only + pkgs, prod, memb,
                       svc_only + pkgs + prod + memb])

    # build employee rows
    dfx_valid = dfx[(dfx['emp_code'] != '') & (dfx['emp_code'].str.lower() != 'nan')].copy()
    inv = dfx_valid.drop_duplicates(subset=['Invoice No','emp_code','outlet_key','day_key']).copy()
    inv['is_new'] = inv['First Visit'].astype(str).str.strip().str.lower() == 'yes'

    e_rows = []
    for (code, name, outlet, day), grp in dfx_valid.groupby(['emp_code','emp_name','outlet_key','day_key'], dropna=False):
        it = grp['Item Type'].astype(str).str.strip()
        pt = grp['Payment Type'].astype(str)
        is_red = pt.str.contains('Package - ', case=False, na=False)
        subs = grp['Item Subcategory'].astype(str)
        svc_mask = (it == 'Service') & (~is_red)
        prod_mask = (it == 'Product')
        pkg_mask  = (it == 'Package')
        mem_mask  = (it == 'Membership')

        svc_only  = float(grp.loc[svc_mask, 'Hybrid Rev'].sum())
        prod_ach  = float(grp.loc[prod_mask, 'Sales Collected (Inc.Tax)'].sum())
        memb_sold = float(grp.loc[mem_mask, 'Sales Collected (Exc.Tax)'].sum())
        pkg_count = int(pkg_mask.sum())
        pkg_value = float(grp.loc[pkg_mask, 'Hybrid Rev'].sum())

        cut_ct   = int((subs.isin(CUT_S)   & svc_mask).sum())
        color_ct = int((subs.isin(COLOR_S) & svc_mask).sum())
        ker_ct   = int((subs.isin(KER_S)   & svc_mask).sum())
        fac_ct   = int((subs.isin(FAC_S)   & svc_mask).sum())
        prod_ct  = int(prod_mask.sum())

        inv_sub = inv[(inv['emp_code']==code) & (inv['outlet_key']==outlet) & (inv['day_key']==day)]
        new_g = int(inv_sub['is_new'].sum())
        exist_g = int((~inv_sub['is_new']).sum())

        e_rows.append([day, outlet, name, pkg_count, pkg_value, svc_only, prod_ach, memb_sold,
                       svc_only + pkg_value + prod_ach + memb_sold,
                       cut_ct, color_ct, ker_ct, fac_ct, prod_ct, new_g, exist_g])

    NAVY = PatternFill('solid', fgColor='FF1F3864')
    thin_side = Side(style='thin', color='BFBFBF')
    BORDER_L = Border(left=thin_side, right=thin_side, top=thin_side, bottom=thin_side)
    HDR_F = Font(name='Cambria', size=10, bold=True, color='FFFFFFFF')

    def merge_history(path, headers, new_rows, cur_dates, widths):
        if os.path.exists(path):
            old_wb = load_workbook(path)
            old_ws = old_wb.active
            kept = []
            for r in range(2, old_ws.max_row + 1):
                d = old_ws.cell(row=r, column=1).value
                if d and str(d) not in cur_dates:
                    kept.append([old_ws.cell(row=r, column=c).value for c in range(1, len(headers)+1)])
        else:
            kept = []

        all_rows = kept + new_rows
        all_rows.sort(key=lambda x: (str(x[0]), str(x[1]), str(x[2]) if len(x) > 2 else ''))

        wb2 = Workbook(); ws2 = wb2.active; ws2.title = 'Sales'
        for i, h in enumerate(headers, start=1):
            c = ws2.cell(row=1, column=i, value=h)
            c.fill = NAVY; c.font = HDR_F; c.border = BORDER_L
            c.alignment = Alignment(wrap_text=True, vertical='center')
        for r_i, r_data in enumerate(all_rows, start=2):
            for i, v in enumerate(r_data, start=1):
                cell = ws2.cell(row=r_i, column=i, value=v)
                cell.border = BORDER_L
                if isinstance(v, (int, float)) and i >= 4:
                    cell.number_format = '#,##0'
        for i, w in enumerate(widths, start=1):
            ws2.column_dimensions[get_column_letter(i)].width = w
        ws2.freeze_panes = 'A2'
        wb2.save(path)
        return len(all_rows)

    o_headers = ['Date','Outlet','Services Only','Packages','Service ACH','Product ACH','Membership Sold','Total Sales']
    e_headers = ['Date','Outlet','Staff','Packages','Packages Rs','Service','Product ACH',
                 'Membership Sold','Total Revenue','Cut Count','Color Count','Keratin Count',
                 'Facial Count','Product Count','New Guests','Old Guests']

    o_path = os.path.join(OUT, f"outlet_sales_history_{year}.xlsx")
    e_path = os.path.join(OUT, f"employee_history_{year}.xlsx")

    n_o = merge_history(o_path, o_headers, o_rows, cur_dates, [12,22,14,12,14,14,16,14])
    n_e = merge_history(e_path, e_headers, e_rows, cur_dates, [12,22,22,10,12,14,14,16,14,10,10,12,11,12,11,11])
    print(f"History updated: {n_o} outlet rows, {n_e} employee rows")

try:
    update_history_files(df_exploded, start_date, end_date)
except Exception as e:
    print(f"WARNING: History update failed: {e}")


wb.save(OUT_FILE)
print()
print("=" * 50)
print("DONE. Output saved to:")
print(OUT_FILE)
print("=" * 50)
