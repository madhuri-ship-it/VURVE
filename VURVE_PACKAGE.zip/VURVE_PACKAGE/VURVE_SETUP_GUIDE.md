# VURVE Daily Sales Tracker — Setup Guide

This guide sets up the daily sales tracker automation on a Mac.
Total time: about 20 minutes, done once.

---

## What this builds

A folder on your Mac. You drop three Excel files in one side, double-click
one icon, and the finished tracker appears in the other side.

It produces:
- `dailysalestracker.xlsx` — 5 sheets (Summary, Daily Sales Tracker,
  Service Category, Retail Product Sales, Employee Performance)
- `outlet_sales_history_2026.xlsx` — cumulative, updated daily
- `employee_history_2026.xlsx` — cumulative, updated daily

---

## STEP 1: Install Python (one time)

1. Open Safari. Go to python.org
2. Click the big yellow "Download Python" button
3. Open the downloaded .pkg file from Downloads
4. Click Continue through the installer windows. Click Agree when asked.
5. Click Install. Enter your Mac login password when prompted.
6. Click Close when it says installation was successful.

VERIFY: Press Command + Space. Type Terminal. Press Enter. In the black
window, type exactly this and press Enter:

    python3 --version

You should see something like "Python 3.13.x". If not, redo Step 1.

Close Terminal.

---

## STEP 2: Install the Excel tools (one time)

1. Open Terminal (Command + Space, type Terminal, Enter)
2. Type exactly this and press Enter:

    python3 -m pip install pandas openpyxl

3. Wait 1-2 minutes while text scrolls by.
4. When it stops and you see the $ or % prompt again, it is done.
5. Close Terminal.

If you see an error about "externally-managed-environment", stop and ask
the person who gave you this guide. Do not try to fix it yourself.

---

## STEP 3: Create the folders

1. Open Finder (the smiling face icon in the Dock)
2. Click Go in the top menu, then Home
3. Right-click in the empty space, choose New Folder. Name it VURVE
4. Open the VURVE folder
5. Inside it, right-click, New Folder. Name it in
6. Right-click again, New Folder. Name it out
7. Right-click again, New Folder. Name it history

You now have: VURVE / in, out, history

---

## STEP 4: Get the three script files

The person who gave you this guide should also give you these three files:

- build_tracker.py
- backfill.py
- Run Tracker.command

Put all three directly inside the VURVE folder (NOT inside in, out, or history).

---

## STEP 5: Make the launcher double-clickable

1. Open Terminal
2. Type: chmod +x ~/VURVE/Run\ Tracker.command
   (note the backslash before the space — it matters)
3. Press Enter
4. Close Terminal

---

## STEP 6: Load the historical Sales-Cash files

Put your monthly Sales-Cash files (April through the current month, one per
month) into ~/VURVE/history/

Name them exactly like this:

    Sales-Cash_2026-04.xlsx
    Sales-Cash_2026-05.xlsx
    Sales-Cash_2026-06.xlsx
    ... and so on

---

## STEP 7: Backfill (one time)

1. Open Terminal
2. Type: python3 ~/VURVE/backfill.py
3. Press Enter
4. Wait 1-2 minutes
5. You should see:

    Wrote /Users/YOU/VURVE/out/outlet_sales_history_2026.xlsx (... rows)
    Wrote /Users/YOU/VURVE/out/employee_history_2026.xlsx (... rows)
    Backfill complete.

This builds the history files. You only do this once.

---

## DAILY ROUTINE (every morning)

1. Delete yesterday's files from ~/VURVE/in/ and ~/VURVE/out/
2. Drop these three files into ~/VURVE/in/:
   - Sales-Cash (whatever Zenoti names it)
   - VURVE DAILY SALES TRACKER.xlsx
   - VURVE_Google_Reviews_2026.xlsx
3. Double-click Run Tracker.command (in the VURVE folder)
4. Wait 10-20 seconds
5. Open ~/VURVE/out/dailysalestracker.xlsx

That's it. One script run updates all three output files.

---

## IMPORTANT: Reading the output in Excel

Excel does NOT auto-refresh when the file changes on disk. If you already
have dailysalestracker.xlsx open in Excel and the script runs, Excel still
shows the OLD numbers.

Always close and reopen the file after a run.

---

## MONTHLY ROLLOVER

At the start of a new month:

1. Make sure VURVE DAILY SALES TRACKER.xlsx has a tab for the new month
   (e.g. OCT26)
2. Make sure VURVE_Google_Reviews_2026.xlsx has a tab for the new month
   (e.g. OCT 26)
3. Keep using the same daily routine

The script picks the correct tab automatically based on the Sales-Cash date.

---

## WHEN THINGS CHANGE

- New outlet opened, or an outlet closed or renamed: ask the person who
  set this up to update the script. The center list is fixed in the code.

- New employee: no action needed. Anyone who sells appears in the
  Employee Performance sheet automatically.

- Employee transfers to another outlet: handled. The outlet comes from
  where the sale happened, not a static list.

- Year rollover (Jan 2027): the script writes to history_2027.xlsx
  automatically.

---

## IF SOMETHING BREAKS

Run the script from Terminal instead of double-clicking, so you can see
the error:

    python3 ~/VURVE/build_tracker.py

Copy the error message and send it to whoever set this up.
Do not try to edit the .py files yourself.

---

## FILE STRUCTURE REFERENCE

~/VURVE/
├── in/                    ← drop today's 3 files here
├── out/                   ← finished files appear here
│   ├── dailysalestracker.xlsx
│   ├── outlet_sales_history_2026.xlsx
│   └── employee_history_2026.xlsx
├── history/               ← monthly Sales-Cash files for backfill
├── build_tracker.py
├── backfill.py
└── Run Tracker.command    ← double-click this each morning
